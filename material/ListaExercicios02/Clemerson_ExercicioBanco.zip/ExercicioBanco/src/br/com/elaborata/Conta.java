package br.com.elaborata;

/**
 * 
 * @author Clemerson Santos
 *
 */
public class Conta{

	private Double saldo;
	private Agencia agencia;
	

	public Conta() {
		this.saldo = 100.00;
	}

	public Double getSaldo() {
		return saldo;
	}

	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}

	public Agencia getAgencia() {
		return agencia;
	}

	public void setAgencia(Agencia agencia) {
		this.agencia = agencia;
	}
	
	public void deposita(Double valor){
		this.saldo += valor;
	}
	
	public void saca(Double valor){
		this.saldo -= valor;
	}

}
