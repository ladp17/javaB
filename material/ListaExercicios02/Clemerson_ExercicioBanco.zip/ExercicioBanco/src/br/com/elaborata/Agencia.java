package br.com.elaborata;

/**
 * 
 * @author Clemerson Santos
 *
 */
public class Agencia {
	private Integer numero;

	public Integer getNumero() {
		return numero;
	}

	public void setNumero(Integer numero) {
		this.numero = numero;
	}

	@Override
	public String toString() {
		return "Agencia [numero=" + numero + "]";
	}

}
