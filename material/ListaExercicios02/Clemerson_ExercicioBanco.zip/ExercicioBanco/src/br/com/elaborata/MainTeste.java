/**
 * 
 */
package br.com.elaborata;

import java.util.Scanner;

/**
 * @author Clemerson Santos
 *
 */
public class MainTeste {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		
		Conta conta = new Conta();
		conta.deposita(60.00);
		
		System.out.println("O salda da conta é: " + conta.getSaldo());
		
		conta.saca(40.00);
		System.out.println("O salda da conta é: " + conta.getSaldo());
		
		/*Cliente cliente = new Cliente();
		cliente.setNome("Clemerson");
		cliente.setCodigo(102030);
		
		System.out.println("O nome do cliente é: "+ cliente.getNome());
		System.out.println("O código do cliente é: "+ cliente.getCodigo());
		
		CartaoDeCredito cartaoDeCredito = new CartaoDeCredito();
		cartaoDeCredito.setNumero(55554444);
		cartaoDeCredito.setDataValidade("22-08-2019");
		cartaoDeCredito.setCliente(cliente);
		
		System.out.println("O numero do cartao de credito é: " + cartaoDeCredito.getNumero());
		System.out.println("A data de validade do cartao de credito é: " + cartaoDeCredito.getDataValidade());
		System.out.println("O nome do cliente é: " + cartaoDeCredito.getCliente());
		
		Agencia agencia = new Agencia();
		agencia.setNumero(814);
		
		System.out.println("O numero da agencia é: " + agencia.getNumero());
		
		Conta conta = new Conta();
		conta.setSaldo(1500.00);
		conta.setAgencia(agencia);
		
		System.out.println("O saldo da conta é: " + conta.getSaldo());
		System.out.println("A agencia da conta é: " + conta.getAgencia());*/
		
		
		scanner.close();
	}

}
