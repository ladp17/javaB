/**
 * 
 */
package br.com.elaborata.exercicios;

/**
 * @author Leo
 *
 */
public class Agencia {

	public Agencia() {
		super();
	}
	
	public Agencia(Integer numero) {
		super();
		this.numero = numero;
	}



	private Integer numero;

	public Integer getNumero() {
		return numero;
	}

	public void setNumero(Integer numero) {
		this.numero = numero;
	}
	
}
