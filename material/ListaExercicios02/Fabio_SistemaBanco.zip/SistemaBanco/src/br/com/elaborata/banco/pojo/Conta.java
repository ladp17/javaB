package br.com.elaborata.banco.pojo;

public class Conta {
	
	private Double saldo;
	private Agencia agencia;
	
	public Conta() {
		this.saldo = 100.00;
	}
	
	public Conta(Agencia agencia) {
		this.agencia = agencia;
		this.saldo = 100.00;
	}

	public Double getSaldo() {
		return saldo;
	}

	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}

	public Agencia getAgencia() {
		return agencia;
	}

	public void setAgencia(Agencia agencia) {
		this.agencia = agencia;
	}
	
	public Boolean sacar (Double valor){
		if (this.saldo >= valor){
			this.saldo -= valor;
			return Boolean.TRUE;
		}else {
			return Boolean.FALSE;
		}
	}	
	
	public Double depositar (Double valor){
		return this.saldo+=valor;
	}

	public void transferir(Conta recebe, Double valor){
		if (this.saldo > 0) {
			this.sacar(valor);
			recebe.depositar(valor);
		} else {
			System.out.println("Saldo Insuficiente");
		}
		
	}
	
	
}
