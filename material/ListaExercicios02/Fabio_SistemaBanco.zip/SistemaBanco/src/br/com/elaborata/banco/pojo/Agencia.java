package br.com.elaborata.banco.pojo;

/**
 * @author Fábio
 *
 */
public class Agencia {
	
	private Integer numeroAgencia;
	
	public Agencia(Integer numero) {
		this.numeroAgencia = numero;
	}

	public Integer getNumeroAgencia() {
		return numeroAgencia;
	}

	public void setNumeroAgencia(Integer numeroAgencia) {
		this.numeroAgencia = numeroAgencia;
	}
	
 

}
