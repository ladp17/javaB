package br.com.elaborata.banco.pojo;

public class CartaoDeCredito {

	private Long numero;
	private String dataValidade;
	private Cliente cliente;

	public CartaoDeCredito(long numero) {

	}

	public Long getNumero() {
		return numero;
	}

	public void setNumero(Long numero) {
		this.numero = numero;
	}

	public String getDataValidade() {
		return dataValidade;
	}

	public void setDataValidade(String dataValidade) {
		this.dataValidade = dataValidade;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

}
