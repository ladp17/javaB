package br.com.elaborata.banco.main;

import br.com.elaborata.banco.pojo.Agencia;
import br.com.elaborata.banco.pojo.CartaoDeCredito;
import br.com.elaborata.banco.pojo.Cliente;
import br.com.elaborata.banco.pojo.Conta;

public class MainBanco {

	public static void main(String[] args) {

		System.out.println("Teste Cliente x Cartao Crédito");
		informacaoClienteCartaoCredito();

		System.out.println("Teste Conta x Agência");
		informacaoAgenciaConta();
		System.out.println("");

		System.out.println("Teste Sacar");
		Conta conta2 = new Conta();
		System.out.println("O saldo é: " + conta2.getSaldo());
		conta2.sacar(50.00);
		System.out.println("O novo saldo é: " + conta2.getSaldo());

		System.out.println("Teste Depositar");
		System.out.println("O saldo é: " + conta2.getSaldo());
		conta2.depositar(300.00);
		System.out.println("O saldo agora é: " + conta2.getSaldo());

		System.out.println("Teste Construtor Conta com parâmetro");
		Agencia agencia2 = new Agencia(4014);
		Conta conta3 = new Conta(agencia2);
		System.out.println("Os dados da Conta são: " + conta3.getAgencia().getNumeroAgencia());

		System.out.println("Teste Transferir");
		Conta conta4 = new Conta();
		Conta conta5 = new Conta();
		System.out.println("O saldo da conta que receberá a transferência é: " + conta5.getSaldo());
		System.out.println("O saldo da conta que vai transferir é: " + conta4.getSaldo());
		conta4.transferir(conta5, 50.00);
		System.out.println("O saldo da conta que recebeu a transferência é: " + conta5.getSaldo());
		System.out.println("O saldo da conta que transferiu é: " + conta4.getSaldo());

	}

	private static void informacaoAgenciaConta() {
		Agencia agencia1 = new Agencia(4014);
		agencia1.setNumeroAgencia(4014);

		Conta conta1 = new Conta();
		conta1.setSaldo(200.00);
		conta1.setAgencia(agencia1);

		System.out.println("O saldo é: " + conta1.getSaldo());
		System.out.println("A agência é: " + conta1.getAgencia().getNumeroAgencia());
	}

	private static void informacaoClienteCartaoCredito() {
		Cliente cliente1 = new Cliente();
		cliente1.setNome("Tiago Nunes");
		cliente1.setCodigo(2019);

		System.out.println("Cliente: " + cliente1.getNome());
		System.out.println("Código: " + cliente1.getCodigo());
		System.out.println();

		CartaoDeCredito cartaoDeCredito1 = new CartaoDeCredito(123456789012l);
		cartaoDeCredito1.setNumero(123456789012l);
		cartaoDeCredito1.setDataValidade("12/2021");
		cartaoDeCredito1.setCliente(cliente1);

		System.out.println("Número do Cartão: " + cartaoDeCredito1.getNumero());
		System.out.println("Validade do Cartão: " + cartaoDeCredito1.getDataValidade());
		System.out.println("Nome do Cliente: " + cartaoDeCredito1.getCliente().getNome());
		System.out.println("Código: " + cartaoDeCredito1.getCliente().getCodigo());
		System.out.println();
	}

}
