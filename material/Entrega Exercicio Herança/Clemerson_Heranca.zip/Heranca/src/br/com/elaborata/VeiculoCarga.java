/**
 * 
 */
package br.com.elaborata;

/**
 * @author Clemerson Santos
 *
 */
public class VeiculoCarga extends Veiculo {

	private Integer capacidade;

	public Integer getCapacidade() {
		return capacidade;
	}

	public VeiculoCarga() {
		// TODO Auto-generated constructor stub
	}

	public VeiculoCarga(Integer capacidade) {
		super();
		this.capacidade = capacidade;
	}

	public VeiculoCarga(String placa, String marca, String modelo, Integer ano, Double valorKmRodado, Double kmInicial,
			Double kmFinal, Integer capacidade) {
		super(placa, marca, modelo, ano, valorKmRodado, kmInicial, kmFinal);
		this.capacidade = capacidade;
	}

	public void setCapacidade(Integer capacidade) {
		this.capacidade = capacidade;
	}

}
