/**
 * 
 */
package br.com.elaborata;

/**
 * @author Clemerson Santos
 *
 */
public class VeiculoPasseio extends Veiculo {

	private Boolean arCondicionado;
	private Integer portas;
	
	public VeiculoPasseio() {
		super();
	}

	public VeiculoPasseio(Boolean arCondicionado, Integer portas) {
		super();
		this.arCondicionado = arCondicionado;
		this.portas = portas;
	}

	public VeiculoPasseio(String placa, String marca, String modelo, Integer ano, Double valorKmRodado,
			Double kmInicial, Double kmFinal, Boolean arCondicionado, Integer portas) {
		super(placa, marca, modelo, ano, valorKmRodado, kmInicial, kmFinal);
		this.arCondicionado = arCondicionado;
		this.portas = portas;
	}

	public Boolean getArCondicionado() {
		return arCondicionado;
	}

	public void setArCondicionado(Boolean arCondicionado) {
		this.arCondicionado = arCondicionado;
	}

	public Integer getPortas() {
		return portas;
	}

	public void setPortas(Integer portas) {
		this.portas = portas;
	}

	public static Double calculaValorLocacao() {
		Double taxa = 0.0;
		
		
		return 0.0;
	}

}
