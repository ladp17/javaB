/**
 * 
 */
package br.com.elaborata;

/**
 * @author Clemerson Santos
 *
 */
public class Veiculo {
	
	private String placa;
	private String marca;
	private String modelo;
	private Integer ano;
	private Double valorKmRodado;
	private Double kmInicial;
	private Double kmFinal;

	public Veiculo() {
		// TODO Auto-generated constructor stub
	}
	
	
	

	public Veiculo(String placa, String marca, String modelo, Integer ano, Double valorKmRodado, Double kmInicial,
			Double kmFinal) {
		super();
		this.placa = placa;
		this.marca = marca;
		this.modelo = modelo;
		this.ano = ano;
		this.valorKmRodado = valorKmRodado;
		this.kmInicial = kmInicial;
		this.kmFinal = kmFinal;
	}




	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public Integer getAno() {
		return ano;
	}

	public void setAno(Integer ano) {
		this.ano = ano;
	}

	public Double getValorKmRodado() {
		return valorKmRodado;
	}

	public void setValorKmRodado(Double valorKmRodado) {
		this.valorKmRodado = valorKmRodado;
	}

	public Double getKmInicial() {
		return kmInicial;
	}

	public void setKmInicial(Double kmInicial) {
		this.kmInicial = kmInicial;
	}

	public Double getKmFinal() {
		return kmFinal;
	}

	public void setKmFinal(Double kmFinal) {
		this.kmFinal = kmFinal;
	}

}
