package br.com.elaborata.heranca;

public class VeiculoCarga extends Veiculo {

	private Integer capacidade;

	public VeiculoCarga() {
		super();

	}

	public VeiculoCarga(Integer capacidade) {
		this.capacidade = capacidade;
	}

	public Integer getCapacidade() {
		return capacidade;
	}

	public void setCapacidade(Integer capacidade) {
		this.capacidade = capacidade;
	}

	public double calculaValorLocacao() {
		Double taxa = 333.00;
		Double valorLocacao = (taxa + super.getValorKmRodado() * (super.getKmFinal() - super.getKmInicial()));
		return valorLocacao;
	}

}
