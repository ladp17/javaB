package br.com.elaborata.heranca;

public class Locadora {
	
	static Double taxa =  0.0;
	
	public static void main(String[] args) {
		
		VeiculoPasseio veiculoPasseio = new VeiculoPasseio(true, 2);
		veiculoPasseio.setModelo("Fiat 147");
		veiculoPasseio.setMarca("Fiat");
		veiculoPasseio.setAno(1968);
		veiculoPasseio.setKmInicial(100.00);
		veiculoPasseio.setKmFinal(120.00);
		veiculoPasseio.setValorKmRodado(3.75);
		
		VeiculoCarga veiculoCarga = new VeiculoCarga(1000);
		veiculoCarga.setModelo("Jabiraca");
		veiculoCarga.setMarca("Volvo");
		veiculoCarga.setAno(1980);
		veiculoCarga.setKmInicial(80.0);
		veiculoCarga.setKmFinal(200.0);
		veiculoCarga.setValorKmRodado(4.25);
		
		
		System.out.println("O valor da locação do Veiculo de Passeio é: " + veiculoPasseio.calculaValorLocacao());
		System.out.println("O valor da locação do Veiculo de Carga é: " + veiculoCarga.calculaValorLocacao());
				

	}
	


}
