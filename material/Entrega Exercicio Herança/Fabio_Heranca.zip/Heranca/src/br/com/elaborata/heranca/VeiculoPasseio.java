package br.com.elaborata.heranca;

public class VeiculoPasseio extends Veiculo {

	private Boolean arCondicionado;
	private Integer numeroPortas;

	public VeiculoPasseio() {
		super();

	}

	public VeiculoPasseio(Boolean arCondicionado, Integer numeroPortas) {
		this.arCondicionado = arCondicionado;
		this.numeroPortas = numeroPortas;
	}

	public Boolean getArCondicionado() {

		return arCondicionado;
	}

	public void setArCondicionado(Boolean arCondicionado) {
		this.arCondicionado = arCondicionado;
	}

	public Integer getNumeroPortas() {
		return numeroPortas;
	}

	public void setNumeroPortas(Integer numeroPortas) {
		this.numeroPortas = numeroPortas;
	}

	public double calculaValorLocacao() {
		Double taxa = 150.00;
		Double valorLocacao = (taxa + super.getValorKmRodado() * (super.getKmFinal() - super.getKmInicial()));
		return arCondicionado ? 235.00 + valorLocacao : valorLocacao;
	}

}
